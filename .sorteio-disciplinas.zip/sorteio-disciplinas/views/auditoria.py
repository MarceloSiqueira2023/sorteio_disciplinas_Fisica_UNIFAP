import inspect
import json

import pandas as pd
import streamlit as st

import core
import ui

ui.cabecalho()
st.title("Auditoria")
st.write("Cada sorteio guarda o seed, os participantes e o hash do sorteio anterior. "
         "Qualquer pessoa pode refazer o cálculo e chegar ao mesmo ganhador.")

log = st.session_state.log
if log:
    resultados = core.verificar(log)
    if all(ok for _, ok in resultados):
        st.success(f"{len(log)} sorteio(s) refeitos e cadeia de hashes íntegra.")
    else:
        st.error("Inconsistência nos sorteios: " + ", ".join(str(n) for n, ok in resultados if not ok))
    st.dataframe(pd.DataFrame(log)[["n", "quando", "disciplina", "ganhador", "seed", "hash"]],
                 hide_index=True)
    st.download_button("Baixar registro (JSON)", json.dumps(log, ensure_ascii=False, indent=2),
                       "auditoria.json", "application/json")
    e = log[-1]
    st.subheader("Verificar o último sorteio por conta própria")
    st.code(f"import random\n"
            f"participantes = {e['participantes']!r}\n"
            f"print(random.Random({e['seed']!r}).choice(sorted(participantes)))  # {e['ganhador']}",
            language="python")
else:
    st.info("Nenhum sorteio realizado ainda.")

st.subheader("Código-fonte do sorteio (core.py)")
st.code(inspect.getsource(core), language="python")
