import json

import streamlit as st

import ui

ui.cabecalho()
st.title("Configurações")

c = st.session_state.cfg
c["instituicao"] = st.text_input("Instituição", c["instituicao"])
c["curso"] = st.text_input("Curso ou colegiado", c["curso"])

aba_p, aba_d, aba_s = st.tabs(["Professores", "Disciplinas", "Salvar e carregar"])

with aba_p:
    with st.form("novo_prof", clear_on_submit=True):
        nome = st.text_input("Nome do professor(a)")
        foto = st.file_uploader("Foto (opcional)", type=["png", "jpg", "jpeg", "webp"])
        st.caption("Para trocar a foto, adicione o mesmo nome com a nova foto.")
        if st.form_submit_button("Salvar professor(a)") and nome.strip():
            nome = nome.strip()
            novo = ui.processar_foto(foto)
            existente = next((p for p in st.session_state.profs if p["nome"] == nome), None)
            if existente:
                existente["foto"] = novo or existente.get("foto")
            else:
                st.session_state.profs.append({"nome": nome, "foto": novo})
            st.rerun()
    for i, p in enumerate(st.session_state.profs):
        a, b, d = st.columns([1, 6, 2], vertical_alignment="center")
        a.markdown(ui.avatar(p, 56), unsafe_allow_html=True)
        b.markdown(f"**{p['nome']}**")
        if d.button("Remover", key=f"rp{i}"):
            st.session_state.profs.pop(i)
            st.rerun()

with aba_d:
    with st.form("novas_discs", clear_on_submit=True):
        texto = st.text_area("Disciplinas (uma por linha)", height=160)
        if st.form_submit_button("Adicionar disciplinas"):
            for linha in texto.splitlines():
                if linha.strip() and linha.strip() not in st.session_state.discs:
                    st.session_state.discs.append(linha.strip())
            st.rerun()
    for i, disc in enumerate(st.session_state.discs):
        a, b = st.columns([8, 2], vertical_alignment="center")
        a.markdown(disc)
        if b.button("Remover", key=f"rd{i}"):
            st.session_state.discs.pop(i)
            st.rerun()

with aba_s:
    st.write("Guarde a configuração para reutilizar no próximo semestre.")
    dados = json.dumps({k: st.session_state[k] for k in ("cfg", "profs", "discs")},
                       ensure_ascii=False, indent=2)
    st.download_button("Baixar configuração (.json)", dados, "sorteio-config.json", "application/json")
    arq = st.file_uploader("Carregar configuração", type="json")
    if arq and st.button("Aplicar configuração"):
        d = json.load(arq)
        for k in ("cfg", "profs", "discs"):
            st.session_state[k] = d.get(k, st.session_state[k])
        st.rerun()
