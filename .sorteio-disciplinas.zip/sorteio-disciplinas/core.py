"""Lógica do sorteio. Este arquivo inteiro é exibido na página de Auditoria.

Como o resultado é decidido:
1. Um seed aleatório é gerado com `secrets` (fonte criptográfica do sistema).
2. O ganhador é `random.Random(seed).choice(...)` sobre a lista ORDENADA
   de participantes. Mesmo seed + mesmos participantes = mesmo ganhador.
3. Cada sorteio é gravado com o hash do anterior (cadeia SHA-256):
   alterar qualquer registro depois quebra a verificação.
"""
import hashlib
import json
import random
import secrets
from datetime import datetime

ZERO = "0" * 64


def novo_seed() -> str:
    return secrets.token_hex(16)


def sortear(participantes: list[str], seed: str) -> str:
    return random.Random(seed).choice(sorted(participantes))


def _hash(entrada: dict) -> str:
    corpo = {k: v for k, v in entrada.items() if k != "hash"}
    texto = json.dumps(corpo, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(texto.encode()).hexdigest()


def registrar(log: list, disciplina: str, participantes: list[str],
              seed: str, ganhador: str) -> dict:
    entrada = {
        "n": len(log) + 1,
        "quando": datetime.now().isoformat(timespec="seconds"),
        "disciplina": disciplina,
        "participantes": sorted(participantes),
        "seed": seed,
        "ganhador": ganhador,
        "anterior": log[-1]["hash"] if log else ZERO,
    }
    entrada["hash"] = _hash(entrada)
    log.append(entrada)
    return entrada


def verificar(log: list) -> list[tuple[int, bool]]:
    """Refaz cada sorteio e confere a cadeia de hashes."""
    resultado, anterior = [], ZERO
    for e in log:
        ok = (
            e["anterior"] == anterior
            and e["hash"] == _hash(e)
            and e["ganhador"] == sortear(e["participantes"], e["seed"])
        )
        resultado.append((e["n"], ok))
        anterior = e["hash"]
    return resultado
